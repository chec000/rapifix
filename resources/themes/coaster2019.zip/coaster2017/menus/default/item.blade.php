<li class="{{ ($item->active)?' active':'' }}">
    <a href="{{ $item->url }}">{{ $item->name }}</a>
</li>