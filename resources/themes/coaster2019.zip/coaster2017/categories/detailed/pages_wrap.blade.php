{!! $links !!}

<div class="row category-detailed">
    {!! $pages !!}
</div>

{!! $links !!}