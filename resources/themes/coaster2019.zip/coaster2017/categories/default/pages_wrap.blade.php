{!! $links !!}

<div class="row categoryrow">
    {!! $pages !!}
</div>

{!! $links !!}