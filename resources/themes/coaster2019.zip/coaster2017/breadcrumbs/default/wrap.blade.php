<div class="row">
    <div class="col-sm-12">
        <ul class="breadcrumb">
            {!! $crumbs !!}
        </ul>
    </div>
</div>